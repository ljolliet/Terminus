/**
 * It is used to read and write in json files.
 */
class IOjson{


    /**
     * @param {string} file the file to read or write.
     */
    constructor(file) {
        this._file = file;
    }

    /**
     * return all places of the _file.json
     */
    getAllPlaces(){

        let obj = JSON.parse("World.json");

        console.log(obj);
    }

    /**
     * return all quests of the _file.json
     */
    getAllQuests(){

    }


    /*  Getters and Setters   */

    getFile(){
        return this._file;
    }

    setFile(file){
        this._file = file;
    }
}